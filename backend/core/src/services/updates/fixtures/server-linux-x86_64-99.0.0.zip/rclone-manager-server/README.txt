Harmless fixture README.
